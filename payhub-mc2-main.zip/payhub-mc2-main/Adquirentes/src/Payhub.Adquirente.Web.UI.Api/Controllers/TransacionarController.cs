﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Payhub.Shared.Contracts.Messages.Autorizar.Requests;
using Payhub.Shared.Contracts.Messages.Autorizar.Responses;
using Payhub.Shared.Contracts.Messages.Cancelar.Requests;
using Payhub.Shared.Contracts.Messages.Capturar.Requests;
using Payhub.Shared.Contracts.Messages.Retentar.Requests;

namespace Payhub.Adquirente.Web.UI.Api.Controllers
{
    //[Produces("application/json")]
    [Route("api/Adquirente")]
    public class TransacionarController : Controller
    {

        [HttpPost, Route("autorizar/Transacao")]
        public async Task<IActionResult> Autorizar([FromBody] AuthOnlyMessageRequest request)
            => AutorizarTransacao(request);

        [HttpPost, Route("capturar/Transacao")]
        public async Task<HttpResponseMessage> Capturar([FromBody] CapturaMessageRequest request)
            => CapturarTransacao(request);

        [HttpPost, Route("cancelar/Transacao")]
        public async Task<HttpResponseMessage> Cancelar([FromBody] CancelaMessageRequest request)
            => CancelaTransacao(request);

        [HttpPost, Route("retentar/Transacao")]
        public async Task<HttpResponseMessage> Retentar([FromBody] RetentaMessageRequest request)
            => RetentarTransacao(request);

        #region Métodos Privados

        private IActionResult AutorizarTransacao(AuthOnlyMessageRequest request)
        {
			//var response = new HttpResponseMessage(HttpStatusCode.OK);
   //         //response.Content = new HttpContent();
   //         return response;

			return Ok(new AuthOnlyMessageResponse());

		}

        private HttpResponseMessage CapturarTransacao(CapturaMessageRequest request)
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK);
            //response.Content = new HttpContent();
            return response;
        }

        private HttpResponseMessage CancelaTransacao(CancelaMessageRequest request)
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK);
            //response.Content = new HttpContent();
            return response;
        }

        private HttpResponseMessage RetentarTransacao(RetentaMessageRequest request)
        {
            var response = new HttpResponseMessage(HttpStatusCode.OK);
            //response.Content = new HttpContent();
            return response;
        }
        #endregion
    }
}
