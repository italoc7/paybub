using AutoMapper;
using Payhub.Adquirentes.Contracts.Stone.Sales;
using Payhub.Shared.Contracts.Messages.Autorizar.Requests;

namespace Payhub.Adquirente.Pagamento.Unit.Test.Integration.Parsers.Profiles
{
	public class SaleOptionsProfile : Profile
	{
		public SaleOptionsProfile()
		{
			CreateMap<SaleOptionsMessageRequest, SaleOptions>();
		}
	}
}