﻿using AutoMapper;
using Payhub.Adquirentes.Contracts.Stone.CreditCardTransactions;
using Payhub.Shared.Contracts.Messages.Autorizar.Requests;

namespace Payhub.Adquirente.Pagamento.Unit.Test.Integration.Parsers.Profiles
{
	public class CreditCardProfile : Profile
	{
		public CreditCardProfile()
		{
			CreateMap<CreditCardMessageRequest, CreditCard>();
		}
	}
}