namespace Payhub.Adquirente.Web.UI.Api.Test.Areas.HelpPage.ModelDescriptions
{
    public class DictionaryModelDescription : KeyValuePairModelDescription
    {
    }
}