using System;
using System.Reflection;

namespace Payhub.Adquirente.Web.UI.Api.Test.Areas.HelpPage.ModelDescriptions
{
    public interface IModelDocumentationProvider
    {
        string GetDocumentation(MemberInfo member);

        string GetDocumentation(Type type);
    }
}