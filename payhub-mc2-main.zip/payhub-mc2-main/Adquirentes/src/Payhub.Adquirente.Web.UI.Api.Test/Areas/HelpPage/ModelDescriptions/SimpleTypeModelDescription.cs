namespace Scorponok.Adquirente.Web.UI.Api.Test.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}