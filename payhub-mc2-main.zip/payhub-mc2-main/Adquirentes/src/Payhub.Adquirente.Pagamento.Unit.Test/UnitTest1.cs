using System;
using Xunit;

namespace Payhub.Adquirente.Pagamento.Unit.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
