﻿
namespace Scorponok.Adquirentes.Contracts.Stone
{

    internal static class ServiceConstants {

        public const string DATE_FORMAT = "yyyy-MM-dd";

        public const string DATE_TIME_FORMAT = "yyyy-MM-ddTHH:mm:ss";
    }
}
