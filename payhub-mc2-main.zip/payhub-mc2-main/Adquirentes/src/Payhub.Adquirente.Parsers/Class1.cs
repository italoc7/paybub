﻿using System;

namespace Payhub.Adquirente.Parsers
{
    public class Class1
    {
    }
}
