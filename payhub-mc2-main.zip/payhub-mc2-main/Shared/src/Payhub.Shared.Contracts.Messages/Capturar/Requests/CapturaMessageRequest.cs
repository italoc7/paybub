﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scorponok.Shared.Contracts.Messages.Capturar.Requests
{
    public class CapturaMessageRequest
    {
    }
}
