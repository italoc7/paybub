﻿namespace Scorponok.Shared.Contracts.Messages.Autorizar.Responses
{
    public class AuthOnlyMessageResponse
	{
        
    }
}
