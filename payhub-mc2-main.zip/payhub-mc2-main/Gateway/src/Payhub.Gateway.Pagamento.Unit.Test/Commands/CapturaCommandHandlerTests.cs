﻿

namespace Scorponok.Gateway.Pagamento.Unit.Test.Commands
{
    public class CapturaCommandHandlerTests
    {
        
    }
}
