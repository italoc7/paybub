﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Scorponok.Gateway.Pagamento.Domain.Enuns
{
    public enum Operadora
    {
        Stone = 1
    }
}
