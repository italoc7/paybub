﻿using Scorponok.Gateway.Pagamento.Domain.Interfaces;

namespace Scorponok.Gateway.Pagamento.Domain.Models.Lojas.IRespository
{
    public interface ILojaRepository : IRepository<Loja>
    {
    }
}
