﻿using Scorponok.Gateway.Pagamento.Domain.Core.Commands;
using System;
using System.Collections.Generic;
using System.Text;

namespace Scorponok.Gateway.Pagamento.Domain.Models.Pedidos.CommandHandlers.Commands
{
    public abstract class BaseEventCommand : Command
    {
    }
}
