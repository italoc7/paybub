﻿using Scorponok.Gateway.Pagamento.Domain.Models.Pedidos.CommandHandlers.Commands;

namespace Scorponok.Gateway.Pagamento.Domain.Models.Transacoes.CommandHandlers.Commands
{
    public class AutorizarTransacaoEventCommand : BaseEventCommand
    {
        public AutorizarTransacaoEventCommand()
        {

        }
    }
}
